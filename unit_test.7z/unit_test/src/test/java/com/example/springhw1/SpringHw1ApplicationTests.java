package com.example.springhw1;

import com.example.springhw1.Controller.DocumentController;
import com.example.springhw1.Entity.Document;
import com.example.springhw1.Service.DocumentService;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import ch.qos.logback.core.testUtil.MockInitialContext;
import ch.qos.logback.core.testUtil.MockInitialContextFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@SpringBootTest
class SpringHw1ApplicationTests {

	@Mock
	private DocumentService service;

	@InjectMocks
	private DocumentController controller;

	@Before("execution(public * com.example.springhw1.Controller.DocumentController.*(..))")
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testCreateDocument() {
		Document document = new Document();
		document.setId(1);
		document.setContent("Test document");

		when(service.CreateDocument(any(Document.class))).thenReturn(document);

		Document result = controller.CreateDocument(document);

		assertEquals(document.getId(), result.getId());
		assertEquals(document.getContent(), result.getContent());

		verify(service, times(1)).CreateDocument(document);
	}

	@Test
	public void testGetDocument() {
		Document document = new Document();
		document.setId(1);
		document.setContent("Test document");

		when(service.GetDocument(1)).thenReturn(document);

		Document result = controller.GetDocument(1);

		assertEquals(document.getId(), result.getId());
		assertEquals(document.getContent(), result.getContent());

		verify(service, times(1)).GetDocument(1);
	}

	@Test
	public void testGetDocument_NonExistentId() {
		when(service.GetDocument(anyInt())).thenThrow(new ResponseStatusException(HttpStatus.NOT_FOUND));

		assertThrows(ResponseStatusException.class, () -> controller.GetDocument(999));
	}

	@Test
	public void testListDocuments() {
		List<Document> documents = new ArrayList<>();
		Document document1 = new Document();
		document1.setId(1);
		document1.setContent("Document 1");
		documents.add(document1);
		Document document2 = new Document();
		document2.setId(2);
		document2.setContent("Document 2");
		documents.add(document2);

		when(service.ListDocuments()).thenReturn(documents);

		List<Document> result = controller.ListDocuments();

		assertEquals(2, result.size());
		assertEquals(document1.getId(), result.get(0).getId());
		assertEquals(document1.getContent(), result.get(0).getContent());
		assertEquals(document2.getId(), result.get(1).getId());
		assertEquals(document2.getContent(), result.get(1).getContent());

		verify(service, times(1)).ListDocuments();
	}

	@Test
	public void testUpdateDocument() {
		Document document = new Document();
		document.setId(1);
		document.setContent("Test document");

		when(service.UpdateDocument(1, document.getContent())).thenReturn(document);

		Document result = controller.UpdateDocument(1, document);

		assertEquals(document.getId(), result.getId());
		assertEquals(document.getContent(), result.getContent());

		verify(service, times(1)).UpdateDocument(1, document.getContent());
	}

	@Test
	public void testDeleteDocument() {
		controller.DeleteDocument(1);
		verify(service, times(1)).DeleteDocument(1);
	}

}
