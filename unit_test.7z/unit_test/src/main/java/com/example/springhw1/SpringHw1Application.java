package com.example.springhw1;

import com.example.springhw1.Entity.Document;
import com.example.springhw1.Service.DocumentService;
import com.example.springhw1.Controller.DocumentController;


import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringHw1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringHw1Application.class, args);
	}

}