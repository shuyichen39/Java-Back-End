package com.example.springhw1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringHw1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
